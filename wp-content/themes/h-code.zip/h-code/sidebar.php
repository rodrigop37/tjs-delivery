<?php
/**
 * The sidebar containing the main widget area
 *
 * @package H-Code
 */
?>

<?php
	hcode_get_sidebar();
?>