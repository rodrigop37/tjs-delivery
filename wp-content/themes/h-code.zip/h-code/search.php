<?php
/**
 * The template for displaying search results pages.
 *
 * @package H-Code
 */
?>
<?php
	get_template_part('templates/pages/layout');
?>